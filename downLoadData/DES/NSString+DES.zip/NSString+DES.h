//
//  Utility.h
//  Kidstutor
//
//  Created by 江志敏 on 14/12/3.
//

#import <Foundation/Foundation.h>
#include <CommonCrypto/CommonCrypto.h>

@interface NSString (DES)

+ (NSString*)doCipher:(NSString*)plainText encryptOrDecrypt:(CCOperation)encryptOrDecrypt key:(NSString*)key;
@end
