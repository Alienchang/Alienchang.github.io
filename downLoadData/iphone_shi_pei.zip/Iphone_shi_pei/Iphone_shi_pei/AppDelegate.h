//
//  AppDelegate.h
//  Iphone_shi_pei
//
//  Created by hangzhang on 14-10-31.
//  Copyright (c) 2014年 hangzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

