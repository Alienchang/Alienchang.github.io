//
//  ViewController.m
//  Iphone_shi_pei
//
//  Created by hangzhang on 14-10-31.
//  Copyright (c) 2014年 hangzhang. All rights reserved.
//

#import "ViewController.h"

FOUNDATION_EXPORT CGRect SETViewFrame(CGRect rect4 ,CGRect rect5 ,CGRect rect6 ,CGRect rect6_ ){

    int height=(int) [UIScreen mainScreen].bounds.size.height;

    if(height==480){
     
        return rect4;
    
    }else if (height==568){
    
    
        return rect5;
    
    }else if (height==667){
    
        return rect6;
    
    }else if (height==736){
    
        return rect6_;
    
    }


    return rect4;

}

FOUNDATION_EXPORT NSString * SETImage(NSString * image){

 
    int height=(int) [UIScreen mainScreen].bounds.size.height;
    
    if(height==480){
        
        return image;
        
    }else if (height==568){
        
        
        return [NSString stringWithFormat:@"%@5",image];
        
    }else if (height==667){
        
        return [NSString stringWithFormat:@"%@6",image];

        
    }else if (height==736){
        
        return [NSString stringWithFormat:@"%@6_",image];
        
    }
    
    
    return [NSString stringWithFormat:@"%@",image];


}


#define ScreenWidth  [UIScreen mainScreen].bounds.size.width


@interface ViewController ()
@end



@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    UIImageView * headImageView=[[UIImageView alloc] init];
    
    self.view.backgroundColor=[UIColor colorWithRed:0.039 green:0.773 blue:0.671 alpha:1];
    
    headImageView.frame=SETViewFrame(CGRectMake((ScreenWidth-97)/2, 20, 97, 97), CGRectMake((ScreenWidth-97)/2, 30, 97, 97), CGRectMake((ScreenWidth-132)/2, 40, 132, 132), CGRectMake((ScreenWidth-161)/2, 50, 161, 161));
    headImageView.image=[UIImage imageNamed:SETImage(@"default_Head_image")];
    
    [self.view addSubview:headImageView];
    
    
    UIImageView * btnImageView=[[UIImageView alloc] init];
    
    //self.view.backgroundColor=[UIColor colorWithRed:0.039 green:0.773 blue:0.671 alpha:1];
    
    btnImageView.frame=SETViewFrame(CGRectMake((ScreenWidth-229)/2, 140, 229, 45), CGRectMake((ScreenWidth-229)/2, 150, 229, 45), CGRectMake((ScreenWidth-287)/2, 190, 287, 56), CGRectMake((ScreenWidth-212)/2, 230, 212, 56));
    btnImageView.image=[UIImage imageNamed:SETImage(@"default_btn_image")];
    
    [self.view addSubview:btnImageView];

    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
